
(function(window){
	var showAbout = function(){
		
	}
	console.log('asdfasfasfasdfasddf');
}(window))